from flask import Flask, jsonify, request
from flask_restful import Resource, Api, reqparse
import json
import joblib
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report
import re
import string
from sklearn.feature_extraction.text import TfidfVectorizer
import os

def wordopt(text):
    text = text.lower()
    text = re.sub('\[.*?\]', '', text)
    text = re.sub("\\W"," ",text) 
    text = re.sub('https?://\S+|www\.\S+', '', text)
    text = re.sub('<.*?>+', '', text)
    text = re.sub('[%s]' % re.escape(string.punctuation), '', text)
    text = re.sub('\n', '', text)
    text = re.sub('\w*\d\w*', '', text)    
    return text

def output_lable(n):
    if n == 0:
        return "Fake News"
    elif n == 1:
        return "Not A Fake News"
    
def manual_testing(news):
    testing_news = {"text":[news]}
    new_def_test = pd.DataFrame(testing_news)
    new_def_test["text"] = new_def_test["text"].apply(wordopt) 
    new_x_test = new_def_test["text"]
    new_xv_test = vectorization.transform(new_x_test)
    pred_LR = model.predict(new_xv_test)

    return output_lable(pred_LR[0])

__location__ = os.path.realpath(
    os.path.join(os.getcwd(), os.path.dirname(__file__)))
model = joblib.load(os.path.join(__location__,"model.joblib"))
vectorization = joblib.load(os.path.join(__location__,"vectorization.joblib"))


app = Flask(__name__)

@app.route('/', methods=['GET']) 
def foo():
    return "Welcome!"
  
@app.route('/getModel', methods=['GET'])
def get_model():
    data = request.args['news']
    return manual_testing(data)
  
  


if __name__ == "__main__":
  app.run(debug=True)